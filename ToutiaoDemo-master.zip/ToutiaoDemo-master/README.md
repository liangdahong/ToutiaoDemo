> 基于[BMDragCellCollectionView](https://github.com/asiosldh/BMDragCellCollectionView)的头条频道编辑效果
