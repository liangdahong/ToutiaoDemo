//
//  BMChannelModel.h
//  ToutiaoDemo
//
//  Created by ___liangdahong on 2017/12/11.
//  Copyright © 2017年 ___liangdahong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BMChannelModel : NSObject

@property (nonatomic, copy) NSString *title; ///< title
@property (nonatomic, assign) Class clas; ///< class

@end
